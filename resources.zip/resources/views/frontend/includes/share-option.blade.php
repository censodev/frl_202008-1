<div class="share-option">
    <span class="title">Chia Sẻ:</span>
    <ul class="social-icon-colored clearfix">
        <li class="facebook"><a href="#"><i class="fa fa-facebook"></i>Facebook</a></li>
        <li class="twitter"><a href="#"><i class="fa fa-twitter"></i>Twitter</a></li>
        <li class="google-plus"><a href="#"><i class="fa fa-google-plus"></i>Google Plus</a></li>
        <li class="pinterest"><a href="#"><i class="fa fa-pinterest-p"></i>Pinterest</a></li>
        <li class="mail"><a href="#"><i class="fa fa-envelope"></i>Mail to Friends</a></li>
    </ul>
</div>