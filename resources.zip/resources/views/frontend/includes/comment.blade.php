<div class="comments-area">
    <div class="section section-service">
        <div class="g-plus" data-action="share" data-href="{{ url()->current() }}"></div>
        <div class="section-content w-100">
            <div class="fb-like" data-href="{{ url()->current() }}"
                 data-layout="standard" data-action="like" data-size="large"
                 data-show-faces="true" data-share="true"></div>
            <div class="fb-comments" data-href="{{  url()->current() }}" data-width="100%" data-numposts="10"></div>
        </div>
    </div>
</div>