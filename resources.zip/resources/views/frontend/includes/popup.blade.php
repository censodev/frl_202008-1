<div id="modal-popup" class="modal">
    <div style="text-align: center; margin-top: 100px;">
        <a href="{{ $popup->link }}" title="{{ $popup->link_title }}" target="_blank">
            <img src="{{ $popup->images }}" alt="{{ $popup->alt_image }}" title="{{ $popup->title_image }}">
            <span class="close-popup"><i class="fa fa-times-circle-o" aria-hidden="true"></i></span>
        </a>
    </div>
</div>
