<div class="banner-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 col-md-6 col-12">
                <div class="banner-img banner-hover mb-30">
                    <a href="{{ $home_default->title_banner_content_1 }}" title="{{ $home_default->title_banner_content_1 }}">
                        <img src="{{ $home_default->banner_content_1 }}" alt="{{ $home_default->title_banner_content_1 }}" title="{{ $home_default->alt_banner_content_1 }}">
                    </a>
                </div>
            </div>
            <div class="col-lg-6 col-md-6 col-12">
                <div class="banner-img banner-hover mb-30">
                    <a href="{{ $home_default->title_banner_content_2 }}" title="{{ $home_default->title_banner_content_2 }}">
                        <img src="{{ $home_default->banner_content_2 }}" alt="{{ $home_default->title_banner_content_2 }}" title="{{ $home_default->alt_banner_content_2 }}">
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
