<div class="area-clone-video-cli hide">
  <div class="col-12 col-sm-4 col-md-3 d-flex align-items-stretch clone-video-cli">
    <div class="card bg-light">
      <div class="card-header text-muted border-bottom-0">
        Embed Video
      </div>
      <div class="card-body pt-0">

        <div class="form-group">
          <textarea name="videos[]" class="form-control" rows="3" placeholder="Nhập embed video" required oninvalid="this.setCustomValidity('Vui lòng nhập embed video.')" oninput="setCustomValidity('')"></textarea>
        </div>

      </div>
      <div class="card-footer">
        <div class="text-right">
          <button class="btn btn-sm btn-danger btn-remove-video" type="button">
            <i class="fas fa-trash"></i> Xóa
          </button>
        </div>
      </div>
    </div>
  </div>
</div>