<div class="clone-question hide">
    <div class="row question-item">
        <div class="col-md-6">
            <label for="type">Câu Hỏi</label>
            <textarea name="title[]" class="form-control" rows="5" required>
            </textarea>
        </div>
        <div class="col-md-6">
            <label for="type">Câu trả lời</label>
            <textarea name="reply[]" class="form-control" rows="5" required>
            </textarea>
        </div>
    </div>
</div>

