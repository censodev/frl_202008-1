<footer class="main-footer">
    <strong>Copyright &copy; 2019 <a href="http://click.edu.vn">Click.edu.vn</a>.</strong>
    All rights reserved.
</footer>
