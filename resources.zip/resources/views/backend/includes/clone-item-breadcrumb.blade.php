<div class="clone-breadcrum hide">
    <div class="row breadcrum-item">
        <div class="col-md-6">
            <label for="type">Name <i class="fa fa-times close-item-breadcrum" aria-hidden="true" style="color: red; cursor: pointer;"></i> </label>
            <input type="text" class="form-control" name="name[]" value="" required oninvalid="this.setCustomValidity('Vui lòng nhập tên.')" oninput="setCustomValidity('')">
        </div>
        <div class="col-md-6">
            <label for="type">Url</label>
            <input type="text" class="form-control" name="url[]" value="" required oninvalid="this.setCustomValidity('Vui lòng nhập url.')" oninput="setCustomValidity('')">
        </div>
    </div>
</div>

