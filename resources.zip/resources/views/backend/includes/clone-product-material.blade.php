<div class="area-clone-material-cli hide">
    <div class="col-md-4 align-items-stretch clone-material-cli">
        <div class="card bg-light">
            <div class="card-body pt-0">
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>Vật Liệu</label>
                            <input type="text" name="name" placeholder="Nhập vật liệu" class="form-control" value="" required>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-footer">
                <div class="text-right">
                    <button class="btn btn-sm btn-danger btn-remove-material" type="button">
                        <i class="fas fa-trash"></i> Xóa
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>
